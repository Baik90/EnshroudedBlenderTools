from dataclasses import dataclass
import struct
import uuid


TEMPLATE_RESOURCE_TYPE_HASH = 0x39768775
COLLIDER_COMPONENT_TYPE_HASH = 0x0E420682
ITEM_INFO_TYPE_HASH = 0xB5CE8765
ITEM_INFO_PLACED_ENTITY_OFFSET = 936
ITEM_INFO_DEBUG_NAME_OFFSET = 1936
ITEM_INFO_EQUIPMENT_SLOT_OFFSET = 260
ITEM_INFO_VISUAL_MODEL_OFFSET = 344
ITEM_INFO_CURSOR_MODEL_OFFSET = 852
ITEM_INFO_CURSOR_SKINNED_MODEL_OFFSET = 868

COLLIDER_TYPES = {}


@dataclass(frozen=True)
class Collider:
    shape: str
    offset: tuple[float, float, float]
    orientation: tuple[float, float, float, float]
    dimensions: tuple[float, ...]
    template_name: str
    template_guid: str


@dataclass(frozen=True)
class TemplateEffect:
    kind: str
    local_offset: tuple[float, float, float]
    world_offset: tuple[float, float, float]
    orientation: tuple[float, float, float, float]
    resource_guid: str
    template_name: str
    template_guid: str
    component_index: int


@dataclass(frozen=True)
class TemplateComponent:
    type_hash: int
    type_name: str
    size: int


@dataclass(frozen=True)
class ModelTemplate:
    name: str
    guid: str
    resource_index: int
    components: tuple[TemplateComponent, ...]
    colliders: tuple[Collider, ...]


@dataclass(frozen=True)
class PlaceableBase:
    template_name: str
    template_guid: str
    item_guid: str


@dataclass(frozen=True)
class EquipmentBase:
    item_name: str
    item_guid: str
    model_name: str
    model_guid: str
    equipment_slot: int
    model_field: str


def _fnv1a32(value: str) -> int:
    result = 0x811C9DC5
    for byte in value.encode("utf-8"):
        result = ((result ^ byte) * 0x01000193) & 0xFFFFFFFF
    return result


COLLIDER_TYPES.update({
    _fnv1a32("keen::ecs::SphereColliderData"): "SPHERE",
    _fnv1a32("keen::ecs::SpheroidColliderData"): "SPHEROID",
    _fnv1a32("keen::ecs::CylinderColliderData"): "CYLINDER",
    _fnv1a32("keen::ecs::CapsuleColliderData"): "CAPSULE",
    _fnv1a32("keen::ecs::TaperedCapsuleColliderData"): "TAPERED_CAPSULE",
    _fnv1a32("keen::ecs::BoxColliderData"): "BOX",
})

_KNOWN_COMPONENT_NAMES = (
    "keen::ecs::Ao",
    "keen::ecs::AttachToSurface",
    "keen::ecs::ActiveNpcTarget",
    "keen::ecs::CheckPlayerInRange",
    "keen::ecs::ClientInteractionLock",
    "keen::ecs::ClientInteractionOffer",
    "keen::ecs::ColliderResourceComponent",
    "keen::ecs::CollisionFeedbackMaterialComponent",
    "keen::ecs::CurrentTransform",
    "keen::ecs::Comfort",
    "keen::ecs::ComfortProvider",
    "keen::ecs::DamageSusceptibility",
    "keen::ecs::Debug",
    "keen::ecs::Destructible",
    "keen::ecs::Health",
    "keen::ecs::InteractionAttachment",
    "keen::ecs::InteractionLock",
    "keen::ecs::InteractionOffer",
    "keen::ecs::IsInWaterCheck",
    "keen::ecs::ModelComponent",
    "keen::ecs::ModelResource",
    "keen::ecs::ModelRenderHint",
    "keen::ecs::OnDestroy",
    "keen::ecs::RandomLoot",
    "keen::ecs::RandomLootContainer",
    "keen::ecs::RandomLootOnDestroy",
    "keen::ecs::RandomLootProbability",
    "keen::ecs::RenderTransform",
    "keen::ecs::ServerTarget",
    "keen::ecs::StaticClientCollider",
    "keen::ecs::StaticCollider",
    "keen::ecs::StaticTransform",
    "keen::ecs::TintColor",
    "keen::ecs::UiOffsets",
    "keen::ecs::AudioComponent",
    "keen::ecs::AudioResourceComponent",
    "keen::ecs::VfxComponent",
    "keen::ecs::VfxComponentResource",
)
COMPONENT_NAMES = {_fnv1a32(name): name.replace("keen::ecs::", "") for name in _KNOWN_COMPONENT_NAMES}


def _relative_array(payload: bytes, field_offset: int, stride: int) -> tuple[int, int]:
    relative, count = struct.unpack_from("<II", payload, field_offset)
    start = field_offset + relative if relative else 0
    if count and (not start or start + count * stride > len(payload)):
        raise ValueError(f"Collider array at 0x{field_offset:x} exceeds TemplateResource")
    return start, count


def _relative_string(payload: bytes, field_offset: int) -> str:
    relative, size = struct.unpack_from("<II", payload, field_offset)
    start = field_offset + relative if relative else 0
    if not start or start + size > len(payload):
        return ""
    return payload[start:start + size].rstrip(b"\0").decode("utf-8", errors="replace")


def _variant_target(payload: bytes, descriptor_offset: int) -> tuple[int, int, int]:
    type_hash, relative, size = struct.unpack_from("<III", payload, descriptor_offset)
    target = descriptor_offset + 4 + relative if relative else 0
    if not target or target + size > len(payload):
        raise ValueError(f"Collider variant at 0x{descriptor_offset:x} exceeds TemplateResource")
    return type_hash, target, size


def _parse_shape(payload: bytes, offset: int, size: int, shape: str) -> tuple[float, ...]:
    shape_offset = offset + 80
    available = offset + size - shape_offset
    counts = {
        "SPHERE": 1,
        "SPHEROID": 2,
        "CYLINDER": 2,
        "CAPSULE": 2,
        "TAPERED_CAPSULE": 3,
        "BOX": 3,
    }
    count = counts[shape]
    if available < count * 4:
        raise ValueError(f"{shape} collider body is too small ({size} bytes)")
    return struct.unpack_from(f"<{count}f", payload, shape_offset)


def parse_template_colliders(payload: bytes, template_guid: str) -> tuple[Collider, ...]:
    """Parse primitive gameplay colliders from a keen::ecs::TemplateResource."""
    if len(payload) < 20:
        return ()
    template_name = _relative_string(payload, 0) or template_guid
    component_start, component_count = _relative_array(payload, 12, 12)
    colliders = []
    for component_index in range(component_count):
        descriptor = component_start + component_index * 12
        type_hash, component_offset, _size = _variant_target(payload, descriptor)
        if type_hash != COLLIDER_COMPONENT_TYPE_HASH:
            continue

        resource_start, resource_count = _relative_array(payload, component_offset, 56)
        for resource_index in range(resource_count):
            resource_offset = resource_start + resource_index * 56
            data_start, data_count = _relative_array(payload, resource_offset, 12)
            for data_index in range(data_count):
                type_hash, body_offset, body_size = _variant_target(
                    payload, data_start + data_index * 12
                )
                shape = COLLIDER_TYPES.get(type_hash)
                if shape is None:
                    continue
                if body_size < 80:
                    raise ValueError(f"{shape} collider header is truncated")
                offset = struct.unpack_from("<3f", payload, body_offset + 8)
                orientation = struct.unpack_from("<4f", payload, body_offset + 20)
                dimensions = _parse_shape(payload, body_offset, body_size, shape)
                colliders.append(Collider(
                    shape=shape,
                    offset=offset,
                    orientation=orientation,
                    dimensions=dimensions,
                    template_name=template_name,
                    template_guid=template_guid,
                ))
    return tuple(colliders)


def parse_template_components(payload: bytes) -> tuple[TemplateComponent, ...]:
    if len(payload) < 20:
        return ()
    component_start, component_count = _relative_array(payload, 12, 12)
    components = []
    for index in range(component_count):
        descriptor = component_start + index * 12
        type_hash, _relative, size = struct.unpack_from("<III", payload, descriptor)
        components.append(TemplateComponent(
            type_hash=type_hash,
            type_name=COMPONENT_NAMES.get(type_hash, f"Unknown 0x{type_hash:08x}"),
            size=size,
        ))
    return tuple(components)


def parse_template_effects(payload: bytes, template_guid: str) -> tuple[TemplateEffect, ...]:
    """Parse editable VFX/audio attachment transforms from a TemplateResource."""
    if len(payload) < 20:
        return ()
    template_name = _relative_string(payload, 0) or template_guid
    component_start, component_count = _relative_array(payload, 12, 12)
    component_hashes = {
        _fnv1a32("keen::ecs::VfxComponent"): "VFX",
        _fnv1a32("keen::ecs::AudioComponent"): "AUDIO",
    }
    resource_hashes = {
        "VFX": _fnv1a32("keen::ecs::VfxComponentResource"),
        "AUDIO": _fnv1a32("keen::ecs::AudioResourceComponent"),
    }
    parsed = []
    pending = {"VFX": [], "AUDIO": []}
    for index in range(component_count):
        descriptor = component_start + index * 12
        type_hash, body, size = _variant_target(payload, descriptor)
        kind = component_hashes.get(type_hash)
        if kind:
            offset_at = body + (8 if kind == "VFX" else 12)
            if offset_at + 40 > body + size:
                raise ValueError(f"{kind} component offset is truncated")
            pending[kind].append((index, struct.unpack_from("<3f", payload, offset_at),
                struct.unpack_from("<3f", payload, offset_at + 12),
                struct.unpack_from("<4f", payload, offset_at + 24)))
            continue
        for resource_kind, resource_hash in resource_hashes.items():
            if type_hash == resource_hash and pending[resource_kind]:
                component_index, local, world, orientation = pending[resource_kind].pop(0)
                resource_guid = str(uuid.UUID(bytes_le=payload[body:body + 16])) if size >= 16 else ""
                parsed.append(TemplateEffect(resource_kind, local, world, orientation,
                    resource_guid, template_name, template_guid, component_index))
                break
    for kind, entries in pending.items():
        for component_index, local, world, orientation in entries:
            parsed.append(TemplateEffect(kind, local, world, orientation, "",
                template_name, template_guid, component_index))
    return tuple(sorted(parsed, key=lambda effect: effect.component_index))


def find_model_templates(reader, model_guid: str) -> tuple[ModelTemplate, ...]:
    model_bytes = uuid.UUID(model_guid).bytes_le
    found = []
    for index, resource_id in enumerate(reader.resource_ids):
        if resource_id.type_hash != TEMPLATE_RESOURCE_TYPE_HASH or resource_id.part_index != 0:
            continue
        payload = reader.read_resource(index)
        if model_bytes not in payload:
            continue
        name = _relative_string(payload, 0) or resource_id.guid
        found.append(ModelTemplate(
            name=name,
            guid=resource_id.guid,
            resource_index=index,
            components=parse_template_components(payload),
            colliders=parse_template_colliders(payload, resource_id.guid),
        ))
    return tuple(found)


def list_placeable_bases(reader) -> tuple[PlaceableBase, ...]:
    """List ItemInfo resources with a valid EquipmentSetup.placedEntity template.

    Offset 936 is 260 (ItemInfo.equipment) + 676
    (EquipmentSetup.placedEntity) in the current reflected game types.
    """
    found = []
    for index, resource_id in enumerate(reader.resource_ids):
        if resource_id.type_hash != ITEM_INFO_TYPE_HASH or resource_id.part_index != 0:
            continue
        payload = reader.read_resource(index)
        start = ITEM_INFO_PLACED_ENTITY_OFFSET
        template_bytes = payload[start:start + 16]
        if len(template_bytes) != 16 or not any(template_bytes):
            continue
        template_guid = str(uuid.UUID(bytes_le=template_bytes))
        try:
            template_index = reader.find_resource_index(
                template_guid, TEMPLATE_RESOURCE_TYPE_HASH
            )
        except KeyError:
            continue
        template_payload = reader.read_resource(template_index)
        template_name = _relative_string(template_payload, 0) or template_guid
        found.append(PlaceableBase(template_name, template_guid, resource_id.guid))
    return tuple(sorted(found, key=lambda item: (item.template_name.casefold(), item.item_guid)))


def list_equipment_bases(reader) -> tuple[EquipmentBase, ...]:
    """List non-placeable ItemInfo resources backed by a static RenderModel.

    The offsets are derived from the current EML reflection data for ItemInfo
    and EquipmentSetup.  ``visualModels`` is intentionally not decoded yet;
    this first pass covers direct visual/cursor model references only.
    """
    from .render_model import RENDER_MODEL_TYPE_HASH

    render_models = {
        resource_id.guid: index
        for index, resource_id in enumerate(reader.resource_ids)
        if resource_id.type_hash == RENDER_MODEL_TYPE_HASH
        and resource_id.part_index == 0
    }
    model_names = {}
    template_models = {}
    template_indices = {rid.guid: i for i, rid in enumerate(reader.resource_ids)
                        if rid.type_hash == TEMPLATE_RESOURCE_TYPE_HASH and rid.part_index == 0}
    found = []
    fields = (
        ("visualModel", ITEM_INFO_VISUAL_MODEL_OFFSET),
        ("cursorModel", ITEM_INFO_CURSOR_MODEL_OFFSET),
        ("cursorSkinnedModel", ITEM_INFO_CURSOR_SKINNED_MODEL_OFFSET),
    )
    for index, resource_id in enumerate(reader.resource_ids):
        if resource_id.type_hash != ITEM_INFO_TYPE_HASH or resource_id.part_index != 0:
            continue
        payload = reader.read_resource(index)
        placed = payload[ITEM_INFO_PLACED_ENTITY_OFFSET:ITEM_INFO_PLACED_ENTITY_OFFSET + 16]
        if len(placed) == 16 and any(placed):
            continue
        selected = None
        for field_name, offset in fields:
            raw_guid = payload[offset:offset + 16]
            if len(raw_guid) != 16 or not any(raw_guid):
                continue
            model_guid = str(uuid.UUID(bytes_le=raw_guid))
            if model_guid in render_models:
                selected = field_name, model_guid
                break
        if selected is None:
            # ItemInfo.equipment (260) + EquipmentSetup.visualEntity (68).
            raw_template = payload[328:344]
            if len(raw_template) == 16 and any(raw_template):
                template_guid = str(uuid.UUID(bytes_le=raw_template))
                if template_guid in template_indices:
                    if template_guid not in template_models:
                        template = reader.read_resource(template_indices[template_guid])
                        start, count = _relative_array(template, 12, 12)
                        models = []
                        for component in range(count):
                            kind, body, size = _variant_target(template, start + component * 12)
                            if kind == _fnv1a32("keen::ecs::ModelResource") and size >= 16:
                                guid = str(uuid.UUID(bytes_le=template[body:body + 16]))
                                if guid in render_models and guid not in models:
                                    models.append(guid)
                        template_models[template_guid] = models
                    models = template_models[template_guid]
                    if len(models) == 1:
                        selected = "visualEntity.ModelResource", models[0]
        if selected is None:
            continue
        field_name, model_guid = selected
        if model_guid not in model_names:
            model_payload = reader.read_resource(render_models[model_guid])
            model_names[model_guid] = _relative_string(model_payload, 0) or model_guid
        item_name = _relative_string(payload, ITEM_INFO_DEBUG_NAME_OFFSET) or resource_id.guid
        slot = payload[ITEM_INFO_EQUIPMENT_SLOT_OFFSET] if len(payload) > ITEM_INFO_EQUIPMENT_SLOT_OFFSET else 0
        found.append(EquipmentBase(
            item_name=item_name,
            item_guid=resource_id.guid,
            model_name=model_names[model_guid],
            model_guid=model_guid,
            equipment_slot=slot,
            model_field=field_name,
        ))
    return tuple(sorted(found, key=lambda item: (item.item_name.casefold(), item.item_guid)))


def find_model_colliders(reader, model_guid: str) -> tuple[Collider, ...]:
    """Find TemplateResources that directly reference a RenderModel GUID."""
    return tuple(
        collider
        for template in find_model_templates(reader, model_guid)
        for collider in template.colliders
    )
